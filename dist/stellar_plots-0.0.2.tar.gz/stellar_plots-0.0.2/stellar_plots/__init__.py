import os
from stellar_plots import *


__all__ = ["driver", "mast_utils", "make_plot", "utils"]


# set Python env variable to keep track of example data dir
stellar_plots_dir = os.path.dirname(__file__) 