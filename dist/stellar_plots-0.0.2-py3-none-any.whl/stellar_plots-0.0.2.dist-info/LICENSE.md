# stellar_plots

A Python code used to generate descriptive plots of properties for a individual stars.
Accepts a list of coordinate (ra/dec) in degrees, of sources to plot.